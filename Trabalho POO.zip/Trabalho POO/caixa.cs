﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Trabalho_POO
{
    public partial class caixa : Form
    {
        private SqlConnection sqlcon = new SqlConnection("Data Source=LUCAS\\SQL;Initial Catalog=Mercado;User ID=sa;Password=esamc123;");
        private decimal totalCompra = 0;

        public caixa()
        {
            InitializeComponent();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
                return;

            if (!int.TryParse(textBox1.Text, out int id))
            {
                MessageBox.Show("Código inválido! Use apenas números.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox7.Clear();
                textBox3.Clear();
                return;
            }

            string strsql = "SELECT nome, preco FROM tbprod WHERE idprod = @id";
            using (SqlCommand cmd = new SqlCommand(strsql, sqlcon))
            {
                cmd.Parameters.AddWithValue("@id", id);
                try
                {
                    sqlcon.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        int rows = 0;
                        while (dr.Read())
                        {
                            rows++;
                            textBox7.Text = dr["nome"] != DBNull.Value ? dr["nome"].ToString() : "";
                            object precoObj = dr["preco"];
                            if (precoObj != DBNull.Value && decimal.TryParse(precoObj.ToString(), out decimal preco))
                            {
                                textBox3.Text = preco.ToString("0.00");
                            }
                            else
                            {
                                textBox3.Text = "0.00";
                            }
                        }
                        if (rows == 0)
                        {
                            MessageBox.Show($"Nenhum produto encontrado com ID {id} na tabela tbprod. Verifique se o ID existe.", "Produto não encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            textBox7.Clear();
                            textBox3.Clear();
                        }
                        else
                        {
                            MessageBox.Show($"Produto encontrado! Linhas: {rows}. Nome: {textBox7.Text}, Preço: {textBox3.Text}", "Depuração", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Erro de SQL: {ex.Message}\nVerifique a conexão, tabela tbprod ou colunas nome/preco.", "Erro de Banco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro inesperado: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (sqlcon.State != ConnectionState.Closed)
                        sqlcon.Close();
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (decimal.TryParse(textBox3.Text, out decimal preco) && int.TryParse(textBox4.Text, out int qtd) && qtd > 0)
            {
                decimal totalItem = preco * qtd;
                textBox5.Text = totalItem.ToString("0.00");
            }
            else
            {
                textBox5.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Preencha o código e a quantidade primeiro!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox7.Text) || string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("O produto não foi encontrado ou os dados não foram carregados corretamente. Digite o código novamente e pressione Tab.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(textBox5.Text, out decimal valorItem))
            {
                MessageBox.Show("Calcule o valor total antes de adicionar!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int n = dataGridView1.Rows.Add();
            dataGridView1.Rows[n].Cells[0].Value = textBox1.Text;
            dataGridView1.Rows[n].Cells[1].Value = textBox7.Text;
            dataGridView1.Rows[n].Cells[2].Value = textBox3.Text;
            dataGridView1.Rows[n].Cells[3].Value = textBox4.Text;
            dataGridView1.Rows[n].Cells[4].Value = textBox5.Text;

            totalCompra += valorItem;
            textBox6.Text = totalCompra.ToString("0.00");

            textBox1.Clear();
            textBox7.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count == 0)
            {
                MessageBox.Show("Nenhum produto adicionado!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult r = MessageBox.Show("Deseja finalizar a compra?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.No)
                return;

            try
            {
                sqlcon.Open();

                string insertCaixa = "INSERT INTO tbcaixa (valortotal) OUTPUT INSERTED.idvenda VALUES (@total)";
                using (SqlCommand cmdCaixa = new SqlCommand(insertCaixa, sqlcon))
                {
                    cmdCaixa.Parameters.AddWithValue("@total", totalCompra);
                    int idVenda = (int)cmdCaixa.ExecuteScalar();

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.IsNewRow) continue;
                        string insertItem = "INSERT INTO tb2 (idvenda, idprod, qt, valort) VALUES (@idvenda, @idprod, @qt, @valort)";
                        using (SqlCommand cmdItem = new SqlCommand(insertItem, sqlcon))
                        {
                            cmdItem.Parameters.AddWithValue("@idvenda", idVenda);
                            cmdItem.Parameters.AddWithValue("@idprod", int.Parse(row.Cells[0].Value.ToString())); // Garante conversão para int
                            cmdItem.Parameters.AddWithValue("@qt", int.Parse(row.Cells[3].Value.ToString())); // Garante conversão para int
                            cmdItem.Parameters.AddWithValue("@valort", decimal.Parse(row.Cells[4].Value.ToString())); // Garante conversão para decimal
                            cmdItem.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show($"Compra registrada com sucesso! ID da venda: {idVenda}", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.Rows.Clear();
                    totalCompra = 0;
                    textBox6.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao finalizar compra: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlcon.State != ConnectionState.Closed)
                    sqlcon.Close();
            }
        }
        private void caixa_Load(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
    }
}