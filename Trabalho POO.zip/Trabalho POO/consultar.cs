﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Trabalho_POO
{
    public partial class consultar : Form
    {
        public consultar()
        {
            InitializeComponent();
        }

        SqlConnection sqlcon = null;
        private string strcon = "Data Source=LUCAS\\SQL;Initial Catalog=Mercado;User ID=sa;Password=esamc123;";
        private string strsql = string.Empty;

        private void button3_Click(object sender, EventArgs e)
        {
            strsql = "SELECT * FROM tbprod WHERE idprod = @idprod";
            sqlcon = new SqlConnection(strcon);
            SqlCommand cmdprod = new SqlCommand(strsql, sqlcon);
            if (!int.TryParse(textBox1.Text, out int idprod))
            {
                MessageBox.Show("Digite um ID válido!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            cmdprod.Parameters.Add("@idprod", SqlDbType.Int).Value = idprod;
            try
            {
                sqlcon.Open();
                SqlDataReader drprod = cmdprod.ExecuteReader();
                if (drprod.Read())
                {
                    txtcodigo.Text = drprod["idprod"].ToString();
                    txtnome.Text = drprod["nome"].ToString();
                    txtpreco.Text = drprod["preco"].ToString();
                    txtquant.Text = drprod["quant"].ToString();
                }
                else
                {
                    MessageBox.Show("Produto não encontrado!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                drprod.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao consultar: " + ex.Message);
            }
            finally
            {
                sqlcon.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtcodigo.Text, out int id))
            {
                MessageBox.Show("Digite um ID válido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            strsql = "UPDATE tbprod SET nome=@nome, preco=@preco, quant=@quant WHERE idprod=@id";
            sqlcon = new SqlConnection(strcon);
            SqlCommand cmd = new SqlCommand(strsql, sqlcon);
            cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
            cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = txtnome.Text;
            cmd.Parameters.Add("@preco", SqlDbType.Decimal).Value = decimal.Parse(txtpreco.Text);
            cmd.Parameters.Add("@quant", SqlDbType.Int).Value = int.Parse(txtquant.Text);
            try
            {
                sqlcon.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Produto atualizado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar: " + ex.Message);
            }
            finally
            {
                sqlcon.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtcodigo.Text, out int id))
            {
                MessageBox.Show("Digite um ID válido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DialogResult confirm = MessageBox.Show("Tem certeza que deseja excluir este produto? Isso removerá também os registros relacionados em vendas.", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.No)
                return;

            sqlcon = new SqlConnection(strcon);
            try
            {
                sqlcon.Open();
                strsql = "DELETE FROM tb2 WHERE idprod = @id";
                SqlCommand cmdDeleteTb2 = new SqlCommand(strsql, sqlcon);
                cmdDeleteTb2.Parameters.Add("@id", SqlDbType.Int).Value = id;
                cmdDeleteTb2.ExecuteNonQuery();

                strsql = "DELETE FROM tbprod WHERE idprod = @id";
                SqlCommand cmdDeleteTbprod = new SqlCommand(strsql, sqlcon);
                cmdDeleteTbprod.Parameters.Add("@id", SqlDbType.Int).Value = id;
                cmdDeleteTbprod.ExecuteNonQuery();

                MessageBox.Show("Produto excluído com sucesso!");
                LimparCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir: " + ex.Message);
            }
            finally
            {
                sqlcon.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void LimparCampos()
        {
            textBox1.Clear();
            txtcodigo.Clear();
            txtnome.Clear();
            txtpreco.Clear();
            txtquant.Clear();
        }

        private void consultar_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}