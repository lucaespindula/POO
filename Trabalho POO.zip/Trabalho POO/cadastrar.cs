﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trabalho_POO
{
    public partial class cadastrar : Form
    {
        public cadastrar()
        {
            InitializeComponent();
        }

        string imagem;
        SqlConnection sqlcon = null;
        private string strcon = "Data Source=LUCAS\\SQL;Initial Catalog=Mercado;User ID=sa;Password=esamc123;";
        private string strsql = string.Empty;

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|All Files (*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imagem = dialog.FileName;
                pictureBox1.ImageLocation = imagem;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(imagem))
            {
                MessageBox.Show("Selecione uma imagem antes de salvar!");
                return;
            }
            if (!File.Exists(imagem))
            {
                MessageBox.Show("Arquivo de imagem não encontrado!");
                return;
            }

            byte[] imagem_byte = File.ReadAllBytes(imagem);
            strsql = "INSERT INTO tbprod (nome, preco, quant, foto) OUTPUT INSERTED.idprod VALUES (@nome, @preco, @quantidade, @fotos)";
            sqlcon = new SqlConnection(strcon);
            SqlCommand comando = new SqlCommand(strsql, sqlcon);
            comando.Parameters.Add("@nome", SqlDbType.VarChar).Value = txtnome.Text;
            comando.Parameters.Add("@preco", SqlDbType.Decimal).Value = decimal.Parse(txtpreco.Text);
            comando.Parameters.Add("@quantidade", SqlDbType.Int).Value = int.Parse(txtquant.Text);
            comando.Parameters.Add(new SqlParameter("@fotos", imagem_byte));

            try
            {
                sqlcon.Open();
                int novoId = (int)comando.ExecuteScalar();
                MessageBox.Show($"Produto cadastrado com sucesso! ID do produto: {novoId}");
                txtnome.Text = "";
                txtpreco.Text = "";
                txtquant.Text = "";
                pictureBox1.Image = null;
                imagem = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao gravar: " + ex.Message);
            }
            finally
            {
                sqlcon.Close();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void cadastrar_Load(object sender, EventArgs e)
        {

        }
    }
}